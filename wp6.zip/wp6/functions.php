<?php

function load_stylesheets()
{
    wp_register_style('stylesheet', get_template_directory_uri() . '/css/style.css', array(), false, 'all');
    wp_enqueue_style('stylesheet');
}
add_action('wp_enqueue_scripts','load_stylesheets');

// menus

add_theme_support('menus');

register_nav_menus(
    array(
        'top-menu' => __('Top Menu', 'theme'),
        'footer-menu' => __('Footer Menu', 'theme'),

        )
    );

// contact form

function profile_data_custom_post_type(){
    $labels = array(
        'name'              => 'Profile',
        'singular_name'     => 'Profile',
        'menu_name'         => 'Candite Profile',
        'name_admin_bar'    => 'Candite Profile',

    );
    $args = array(
        'labels' => $labels,
        'show_ui' => true,
        'show_in_menu' =>true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 26,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => array('title', 'editor','author')
    );
    register_post_type('profile-details', $args);
}
add_action('init','profile_data_custom_post_type');

function getProfileInfo(){
    $data_db = array(
        'first_name' => $_POST['first_name'],
        'last_name' => $_POST['last_name'],
        'email' => $_POST['email'],
        'gender' => $_POST['gender'],
        'phone_number' => $_POST['phone_number'],
        'state' => $_POST['state'],
        'city' => $_POST['city'],
        // 'image' => $_FILES['image'],
        'image' => "http://localhost:8080/assignment/wp-content/themes/wp6/uploads/".$_FILES['image']['name'],
        // 'image' => $target_img,
        'graduation_degree'  =>$_POST['graduation_degree'],
        'grade' =>$_POST['grade'],
        'graduation_year' =>$_POST['graduation_year'],
        'specialisation' =>$_POST['specialisation'],
        'college' =>$_POST['college'],
        'primary_skills' =>$_POST['primary_skills'],
        'secondary_skills' =>$_POST['secondary_skills'],
        'certifications' =>$_POST['certifications'],
        'pitch' =>$_POST['pitch'],

    );
    return $data_db;
}


?>