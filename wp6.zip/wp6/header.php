<!DOCTYPE html>
<!-- <html lang="en"> -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head();?>

</head>
<body <?php body_class(); ?>>

<header>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- <div class="container">
    <?php // wp_nav_menu(
    //     array(
    //         'theme_location'=>'top-menu',
    //         'menu_class'=>'navigation'
    //     )
    // )?>
</div> -->
</header>
    
