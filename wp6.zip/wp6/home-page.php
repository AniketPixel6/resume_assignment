<?php
/*
Template Name: Home Page
Template Post Type: post, page, services
*/

get_header(); 


?>

<section  class="body-section">
    <div class="container">
        <div class="candidate-info">
            <h1>Profile Submission</h1>
        </div>
    </div>    
<div class="container">
    <form id="profile_form" action="profile-page"  method="post" enctype="multipart/form-data">
    <div class="first-block">
        <label for="first_name">Personal:</label>
        <div class="form-container">
            <div class="form-group">
                <input type="text" name="first_name" id="first_name" placeholder="First Name*">
                
            </div>
            <div class="form-group">
                <input type="text" name="last_name"  id="last_name" placeholder="Last Name">
            </div>
            <div class="form-group from-radio">
                <p id="gender">Gender*</p>
                <input type="radio" id="male" name="gender" value="male">
                <label for="male">Male</label><br>
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female</label><br>
            </div>
            <div class="form-group">
                <input type="text" name="email" id="email" placeholder="Email*">
            </div>
            <div class="form-group">
                <input type="text" name="phone_number"  id="phone_number" placeholder="Phone Number">
            </div>
            <div class="form-group">
                <select name="state" id="state">
                    <option value="0">State</option>
                    <option value="maharashtra">Maharashtra</option>
                    <option value="AP">AP</option>
                    <option value="UP">UP</option>
                    <option value="Mp">MP</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text"  name="city" id="city" placeholder="City*">
            </div>
            <div class="form-group">
                <input type="file" name="image" id="photo"  accept="image/*">
            </div>
        </div> 
    </div>
    <div class="second-block">
        <label for="graduation">Education:</label>
        <div class="form-container">
            <div class="form-group">
                <select name="graduation_degree" id="graduation_degree">
                    <option value="0" >Graduation Degree*</option>
                    <option value="btech">BTech</option>
                    <option value="ug">UG</option>
                    <option value="pg">PG</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text" name="grade" id="grade" placeholder="Graduation Grade/percentage">
            </div>
            <div class="form-group">
                <select name="graduation_year" id="graduation_year">
                    <option value="0" >Graduation Year*</option>
                    <option value="2021">2021</option>
                    <option value="2020">2020</option>
                    <option value="2019">2019</option>
                    <option value="2018">2018</option>
                    <option value="2017">2017</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text" name="specialisation" id="specialisation" placeholder="Specialisation*">
            </div>
            <div class="form-group">
                <input type="text" name="college" id="college" placeholder="College/University*">
            </div>   
        </div> 
    </div>


    <div class="third-block">
        
        <label for="graduation">Skills:</label>
        <div class="form-container">
            <div class="form-group">
                <input type="text" name="primary_skills" id="primary_skills" placeholder="Primary Skills*">
            </div>
            <div class="form-group">
                <input type="text" name="secondary_skills" id="secondary" placeholder="Secondary">
            </div>
            <div class="form-group">
                <input type="text" name="certifications" id="certifications" placeholder="Certifications">
            </div>
        </div>
    </div>
    <div class="forth-block">
        <label for="pitch">Pitch*</label>
        <div class="form-container">
            <textarea  name="pitch" id="pitch" placeholder="Why should we consider you?" ></textarea>
        </div>
    </div>
    <div class="submit-btn">
        <input type="submit" value="Submit" id="submitbtn" name="submitbtn" >
        <!-- <button class="submit" type="button" name="submitbtn" value="Submit" id="submitbtn">Submit</button> -->
    </div>
</form>

    </div>
</section>








<?php get_footer(); ?>
<script>
jQuery(document).ready(function($) {
jQuery(function($) {
$('#submitbtn').click(function(){

var name = document.getElementById("first_name").value;
if (name == "" || name == null) {
alert("Name field must be filled!");
return false;
}


var male = document.getElementById("male").checked;
var female = document.getElementById("female").checked;

if (male || female) {
    // alert("Please select a Gender.");
}else{
    alert("Please select a Gender.");
    return false;  
}

var email = document.forms["profile_form"]["email"].value;
var at_position = email.indexOf("@");
var dot_position = email.lastIndexOf(".");
if (at_position<1 || dot_position<at_position+2 || dot_position+2>=email.length) {
alert("Given email address is not valid.");
return false;
}

var city = document.getElementById("city").value;
if (city == "" || city == null) {
alert("City field must be filled!");
return false;  
}

var graduation_degree = document.forms["profile_form"]["graduation_degree"].value;
if (graduation_degree == "0" || graduation_degree == null) {
    alert("Please select a Graduation Degree.");
    return false; 
}

var graduation_year = document.forms["profile_form"]["graduation_year"].value;
if (graduation_year == "0" || graduation_year == null) {
    alert("Please select a Graduation Year.");
    return false; 
}

var specialisation = document.getElementById("specialisation").value;
if (specialisation == "" || specialisation == null) {
alert("Specialisation field must be filled!");
return false;  
}

var college = document.getElementById("college").value;
if (college == "" || college == null) {
alert("College field must be filled!");
return false; 
}

var primary_skills = document.getElementById("primary_skills").value;
if (primary_skills == "" || primary_skills == null) {
alert("Primary Skills field must be filled!");
return false; 
}

var pitch = document.getElementById("pitch").value;
if (pitch == "" || pitch == null) {
alert("Pitch field must be filled!");
return false; 
}



var phone = document.forms["profile_form"]["phone_number"].value;
if (phone == "" || phone == null) {
if(!isNaN(phone)){
alert("Please enter correct phone number.");
}
return false;
}





var state = document.forms["profile_form"]["state"].value;
if (state == "0" || state == null) {
    alert("Please select a state.");
    return false;
}

document.forms["profile_form"].submit();
});
});
});



</script>