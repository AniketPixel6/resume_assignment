<?php
/*
Template Name: Profile Page
Template Post Type: post, page, services
*/

get_header(); 


if(isset($_POST['submitbtn'])){
    
    define ('SITE_ROOT', realpath(dirname(__FILE__)));
    $file_name = $_FILES['image']['name'];
    $file_tmp_name = $_FILES['image']['tmp_name'];
    $target = SITE_ROOT."\\uploads\\".$file_name;
    $target_img = "http://localhost:8080/assignment/wp-content/themes/wp6/uploads/".$file_name;
    
    $data = getProfileInfo();

    move_uploaded_file($file_tmp_name, $target);

    $table_name = 'candidate_info';
    $result = $wpdb->insert($table_name, $data, $format=Null); 
    

    if($result == 1){
        echo "<script>alert('candidate info saved');</script>";
    }else{
        echo "<script>alert('Unable to save');</script>";

    }
}

global $wpdb;
// $result = $wpdb->get_results("select * from candidate_info");
$result = $wpdb->get_results("select * from candidate_info ORDER BY id DESC LIMIT 1");

foreach($result as $profile){
?>
<section class="body-section">
    <div class="container">
        <div class="img-container">
            <?php if($profile->image){?>
            <div class="img-block">
                <img src="<?php echo $profile->image; ?>" alt="image">
            </div>
            <?php } ?>
            <h1><?php echo $profile->first_name; ?></h1>
        </div>
        <div class="candidate-info">
            <p><?php echo ($profile->gender == 'male') ? 'Mr. ':'Mrs ';?><?php echo $profile->first_name; ?> did <?php echo ($profile->gender == 'male') ? 'his ':'her ';?><?php echo $profile->graduation_degree; ?> in <?php echo $profile->specialisation; ?>
             from <?php echo $profile->college; ?> in the year <?php echo $profile->graduation_year; ?>. <?php echo ($profile->gender == 'male') ? 'He':'She';?>  is highly skilled in <?php echo $profile->primary_skills; ?>.
              <?php echo ($profile->gender == 'male') ? 'He':'She';?> lives in <?php echo $profile->city; ?>  and can be contacted via <?php echo $profile->email; ?> and <?php echo $profile->phone_number; ?>.</p>
        </div>
    </div>
    <div class="container">
        <h3>Personal</h3>
        <div class="personal-info">
            <ul>
                <li class="info-detail">
                    <div class="clearfix">
                        <span class="info-label">First Name:</span>
                        <span class="info-content"><?php echo $profile->first_name; ?></span>
                    </div>
                </li>
                <li class="info-detail">
                    <div class="clearfix">
                        <span class="info-label">Email:</span>
                        <span id="info_mail" class="info-content"><?php echo $profile->email; ?></span>
                    </div>
                </li>
                <li class="info-detail">
                    <span class="info-label">Last Name:</span>
                    <span class="info-content"><?php echo $profile->last_name; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Phone:</span>
                    <span class="info-content"><?php echo $profile->phone_number; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Gender:</span>
                    <span class="info-content"><?php echo $profile->gender; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Lives in:</span>
                    <span class="info-content"><?php echo $profile->city; ?>, <?php echo $profile->state; ?></span>
                </li>
            </ul>
        </div>
    </div>
    <div class="container">
        <h3>Education</h3>
        <div class="education-info">
            <ul>
                <li class="info-detail">
                    <span class="info-label">Graduation:</span>
                    <span class="info-content"><?php echo $profile->graduation_degree; ?> in <?php echo $profile->specialisation; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Pass out:</span>
                    <span class="info-content"><?php echo $profile->graduation_year; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">College/Univ:</span>
                    <span class="info-content"><?php echo $profile->college; ?></span>
                </li>
            </ul>
        </div>
    </div>
    <div class="container">
        <h3>Skills</h3>
        <div class="skills-info">
            <ul>
                <li class="info-detail">
                    <span class="info-label">Primary:</span>
                    <span class="info-content"><?php echo $profile->primary_skills; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Secondary:</span>
                    <span class="info-content"><?php echo $profile->secondary_skills; ?></span>
                </li>
                <li class="info-detail">
                    <span class="info-label">Certification:</span>
                    <span class="info-content"><?php echo $profile->certifications; ?></span>
                </li>
            </ul>
        </div>
    </div>
    <div class="container">
        <h3><?php echo $profile->first_name; ?> PITCH</h3>
        <div class="pitchs-info">
            <div class="pitch-details">
                <p><?php echo $profile->pitch; ?></p>
            </div>
        </div>
    </div>

</section>

<?php  } ?>
<?php get_footer(); ?>