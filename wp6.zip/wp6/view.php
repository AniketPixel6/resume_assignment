<?php 

/*
Template Name: view Page
Template Post Type: post, page, services
*/

get_header(); 


// $data = getProfileInfo();
// print_r($data);


$result = $wpdb->get_results("select * from candidate_info");
// print_r($result);
$productId =  $_GET['Id'];

print_r($productId);

?>
<div class="container">
        <div class="img-container">
            <div class="img-block">
                <img src="<?php echo $profile->image; ?>" alt="image">
            </div>
            <h1><?php echo $profile->first_name; ?></h1>
        </div>
        <div class="candidate-info">
            <p><?php echo ($profile->gender == 'male') ? 'Mr. ':'Mrs ';?><?php echo $profile->first_name; ?> did <?php echo ($profile->gender == 'male') ? 'his ':'her ';?><?php echo $profile->graduation_degree; ?> in <?php echo $profile->specialisation; ?>
             from <?php echo $profile->college; ?> in the year <?php echo $profile->graduation_year; ?>. <?php echo ($profile->gender == 'male') ? 'He':'She';?>  is highly skilled in <?php echo $profile->primary_skills; ?>.
              <?php echo ($profile->gender == 'male') ? 'He':'She';?> lives in <?php echo $profile->city; ?>  and can be contacted via <?php echo $profile->email; ?> and <?php echo $profile->phone_number; ?>.</p>
        </div>
    </div>


    <?php get_footer(); ?>